package com.example.lab10;

public class Constants {
    public static final String UPDATE_Person_Id = "update_task";
}
